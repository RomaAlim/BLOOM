//
//  AdminMainVC.swift
//  BLOOM
//
//  Created by Ramazan Kalabay on 20.04.2023.
//

import UIKit

class AdminMainVC: UIViewController {


    
    override func viewDidLoad() {
        super.viewDidLoad()

    }



}
